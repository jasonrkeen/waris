"""WARIS prototype package."""
